<?php

namespace Plugins\StaticPosts\Models;

use App\Models\Post;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\MorphToMany;

class StaticPost extends Post
{
    protected static function booted(): void
    {
        parent::booted();

        // Always scope to static_post type when using this model
        static::addGlobalScope('static_post_type', function (Builder $query) {
            $query->where('type', 'static_post');
        });
    }

    // Static categories relation (taxonomy key static_category)
    public function categories(): MorphToMany
    {
        return $this->terms()->whereHas('taxonomy', fn($q) => $q->where('key', 'static_category'));
    }
}
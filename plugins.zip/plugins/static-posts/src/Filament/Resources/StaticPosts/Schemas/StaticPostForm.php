<?php

namespace Plugins\StaticPosts\Filament\Resources\StaticPosts\Schemas;

use App\Cms\Content\PermalinkManager;
use App\Filament\Forms\Components\MediaPicker;
use App\Filament\Forms\Components\WpClassicEditor;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Filament\Schemas\Schema;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Plugins\StaticPosts\Models\StaticPost;

class StaticPostForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->columns(['default' => 1, 'lg' => 3])
            ->components([

                // LEFT: Tabs (2/3)
                Tabs::make('Editor')
                    ->columnSpan(['default' => 1, 'lg' => 2])
                    ->tabs([

                        // ✅ Content tab
                        Tab::make('Content')
                            ->schema([
                                TextInput::make('title')
                                    ->required()
                                    ->maxLength(255)
                                    ->live(onBlur: true)
                                    ->afterStateUpdated(function ($state, Set $set, Get $get) {
                                        if (!filled($get('slug'))) {
                                            $set('slug', Str::slug((string) $state));
                                        }
                                    }),

                                TextInput::make('slug')
                                    ->label('Slug (optional)')
                                    ->maxLength(255)
                                    ->regex('/^[a-z0-9]+(?:-[a-z0-9]+)*$/')
                                    ->live(onBlur: true)
                                    ->afterStateUpdated(function ($state, Set $set) {
                                        $set('slug', filled($state) ? Str::slug((string) $state) : null);
                                    })
                                    ->dehydrateStateUsing(fn($state) => filled($state) ? Str::slug((string) $state) : null)
                                    ->rule(function (?StaticPost $record) {
                                        return Rule::unique('posts', 'slug')->ignore($record?->id);
                                    })
                                    ->helperText('Leave blank to auto-generate. Must be globally unique (posts + pages).'),

                                // Optional permalink preview (like Posts)
                                Placeholder::make('permalink_preview')
                                    ->label('Permalink')
                                    ->content(function (?StaticPost $record, Get $get) {
                                        $base = rtrim((string) config('app.url'), '/');
                                        $slug = trim((string) $get('slug'), '/');
                                        if ($slug === '') {
                                            $slug = Str::slug((string) ($get('title') ?? ''));
                                        }
                                        $slug = $slug !== '' ? $slug : '(auto)';
                                        return "{$base}/static/{$slug}";
                                    }),

                                // Content editor (same component behavior)
                                WpClassicEditor::make('content_json')
                                    ->label('Content')
                                    ->height(320)
                                    ->columnSpanFull()
                                    ->formatStateUsing(function ($state): string {
                                        if (is_array($state)) {
                                            $html = $state['html'] ?? '';
                                            return is_string($html) ? $html : '';
                                        }
                                        return is_string($state) ? $state : '';
                                    })
                                    ->dehydrateStateUsing(function ($state, Get $get): array {
                                        $current = $get('content_json');
                                        if (!is_array($current)) {
                                            $current = [];
                                        }
                                        $current['html'] = is_string($state) ? $state : '';
                                        return $current;
                                    }),

                                Textarea::make('excerpt')
                                    ->label('Excerpt')
                                    ->rows(4)
                                    ->maxLength(2000)
                                    ->nullable(),
                            ]),

                        // ✅ Custom CSS & JS + JSON tab (same as Posts)
                        Tab::make('Custom CSS & JS')
                            ->schema([
                                Textarea::make('meta_json.assets.css')
                                    ->label('Custom CSS (Paste Row CSS Without <style> tags)')
                                    ->helperText('Applies to this post only. Output inside <head>.')
                                    ->rows(14)
                                    ->extraAttributes([
                                        'style' => 'font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;',
                                    ])
                                    ->live(onBlur: true),

                                Textarea::make('meta_json.assets.js')
                                    ->label('Custom JS (Paste Script Without <script> tags)')
                                    ->helperText('Applies to this post only. Output before </body>.')
                                    ->rows(14)
                                    ->extraAttributes([
                                        'style' => 'font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;',
                                    ])
                                    ->live(onBlur: true),

                                Textarea::make('meta_json.custom_json')
                                    ->label('Custom JSON (Paste Valid JSON)')
                                    ->helperText('Valid JSON only. Saved per post. (Do not include <script> tag)')
                                    ->rows(18)
                                    ->nullable()
                                    ->rules(['json'])
                                    ->formatStateUsing(function ($state) {
                                        if (blank($state)) {
                                            return '';
                                        }
                                        if (is_array($state)) {
                                            return json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '';
                                        }
                                        return (string) $state;
                                    })
                                    ->dehydrateStateUsing(function ($state) {
                                        if (blank($state)) {
                                            return null;
                                        }
                                        $decoded = json_decode((string) $state, true);
                                        return $decoded ?? (string) $state;
                                    }),
                            ]),

                        // ✅ Frontend Preview tab (same idea)
                        Tab::make('Frontend Preview')
                            ->schema([
                                Placeholder::make('frontend_preview')
                                    ->label('')
                                    ->content(function (?StaticPost $record) {
                                        if (!$record) {
                                            return new \Illuminate\Support\HtmlString(
                                                '<div class="text-sm text-gray-600">Save the post first to preview the real frontend page.</div>'
                                            );
                                        }
                                        $url = url('/static/' . $record->slug);
                                        return new \Illuminate\Support\HtmlString(
                                            '<a class="text-primary-600 underline" target="_blank" href="' . e($url) . '">' . e($url) . '</a>'
                                        );
                                    }),
                            ]),
                    ]),

                // RIGHT: Publish panel (1/3)
                Section::make('Publish')
                    ->columnSpan(['default' => 1, 'lg' => 1])
                    ->schema([

                        Select::make('status')
                            ->options([
                                'draft' => 'Draft',
                                'published' => 'Published',
                                'scheduled' => 'Scheduled',
                            ])
                            ->default('published')
                            ->required(),

                        Select::make('meta_json.template')
                            ->label('Template')
                            ->helperText('If selected, frontend will use that template. If empty, theme default view is used.')
                            ->options([
                                '' => 'Theme Default (static-posts/show.blade.php)',
                                'default' => 'Default',
                            ])
                            ->default('')
                            ->native(false)
                            ->dehydrateStateUsing(fn($state) => is_string($state) ? $state : ''),

                        MediaPicker::make('featured_media_ids')
                            ->label('Featured Images')
                            ->modalHeading('Featured images')
                            ->multiple()
                            ->maxItems(20),

                        MediaPicker::make('product_media_ids')
                            ->label('Product Images')
                            ->modalHeading('Product images')
                            ->multiple()
                            ->maxItems(50),

                        // ✅ Static Categories (taxonomy static_category) via StaticPost model categories() relation
                        Select::make('categories')
                            ->label('Categories')
                            ->relationship('categories', 'name')
                            ->multiple()
                            ->searchable()
                            ->preload()
                            ->optionsLimit(50),

                        // ✅ NEW FIELD: SVG Icon Code (plugin-only field)
                        Textarea::make('meta_json.static_posts.svg_icon')
                            ->label('SVG Icon (code)')
                            ->helperText('Paste raw SVG code. Saved in meta_json.static_posts.svg_icon for frontend.')
                            ->rows(6)
                            ->extraAttributes([
                                'style' => 'font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;',
                            ])
                            ->nullable(),
                    ]),
            ]);
    }
}
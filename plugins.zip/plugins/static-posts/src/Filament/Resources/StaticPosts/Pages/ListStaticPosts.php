<?php

namespace Plugins\StaticPosts\Filament\Resources\StaticPosts\Pages;

use Filament\Resources\Pages\ListRecords;
use Plugins\StaticPosts\Filament\Resources\StaticPosts\StaticPostResource;

class ListStaticPosts extends ListRecords
{
    protected static string $resource = StaticPostResource::class;
}
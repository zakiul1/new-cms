<?php

namespace Plugins\StaticPosts\Filament\Resources\StaticPosts\Pages;

use Filament\Notifications\Notification;
use Filament\Resources\Pages\EditRecord;
use Filament\Support\Enums\Width;
use Illuminate\Support\Facades\Cache;
use Plugins\StaticPosts\Filament\Resources\StaticPosts\StaticPostResource;

class EditStaticPost extends EditRecord
{
    protected static string $resource = StaticPostResource::class;

    /** @var int[] */
    protected array $featuredMediaIds = [];

    /** @var int[] */
    protected array $productMediaIds = [];

    public function getMaxContentWidth(): Width
    {
        return Width::Full;
    }

    protected function mutateFormDataBeforeFill(array $data): array
    {
        $data['featured_media_ids'] = $this->record?->mediaPivot()
            ->wherePivot('role', 'featured')
            ->orderBy('post_media.sort_order')
            ->pluck('media.id')
            ->map(fn($v) => (int) $v)
            ->values()
            ->all() ?? [];

        $data['product_media_ids'] = $this->record?->mediaPivot()
            ->wherePivot('role', 'product')
            ->orderBy('post_media.sort_order')
            ->pluck('media.id')
            ->map(fn($v) => (int) $v)
            ->values()
            ->all() ?? [];

        return $data;
    }

    protected function mutateFormDataBeforeSave(array $data): array
    {
        $this->featuredMediaIds = is_array($data['featured_media_ids'] ?? null)
            ? array_values(array_filter(array_map(fn($v) => (int) $v, $data['featured_media_ids'])))
            : [];
        unset($data['featured_media_ids']);

        $this->productMediaIds = is_array($data['product_media_ids'] ?? null)
            ? array_values(array_filter(array_map(fn($v) => (int) $v, $data['product_media_ids'])))
            : [];
        unset($data['product_media_ids']);

        $data['featured_media_id'] = $this->featuredMediaIds[0] ?? null;

        return $data;
    }

    protected function afterSave(): void
    {
        $this->syncMediaRole('featured', $this->featuredMediaIds);
        $this->syncMediaRole('product', $this->productMediaIds);

        Cache::forget('cms:sitemap:xml:v2');

        Notification::make()
            ->title('Static Post updated')
            ->success()
            ->send();
    }

    private function syncMediaRole(string $role, array $idsIn): void
    {
        if (!$this->record) {
            return;
        }

        $seen = [];
        $ids = [];
        foreach ($idsIn as $id) {
            $id = (int) $id;
            if ($id <= 0 || isset($seen[$id])) {
                continue;
            }
            $seen[$id] = true;
            $ids[] = $id;
        }

        if ($ids === []) {
            $this->record->mediaPivot()->wherePivot('role', $role)->detach();
            return;
        }

        $sync = [];
        foreach ($ids as $i => $id) {
            $sync[$id] = ['role' => $role, 'sort_order' => $i];
        }

        $this->record->mediaPivot()->wherePivot('role', $role)->detach();
        $this->record->mediaPivot()->attach($sync);
    }
}
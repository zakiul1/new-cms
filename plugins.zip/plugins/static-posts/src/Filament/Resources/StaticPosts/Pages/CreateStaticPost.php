<?php

namespace Plugins\StaticPosts\Filament\Resources\StaticPosts\Pages;

use App\Cms\Content\Slugger;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\CreateRecord;
use Filament\Support\Enums\Width;
use Illuminate\Support\Facades\Cache;
use Plugins\StaticPosts\Filament\Resources\StaticPosts\StaticPostResource;

class CreateStaticPost extends CreateRecord
{
    protected static string $resource = StaticPostResource::class;

    /** @var int[] */
    protected array $featuredMediaIds = [];

    /** @var int[] */
    protected array $productMediaIds = [];

    public function getMaxContentWidth(): Width
    {
        return Width::Full;
    }

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        $this->featuredMediaIds = is_array($data['featured_media_ids'] ?? null)
            ? array_values(array_filter(array_map(fn($v) => (int) $v, $data['featured_media_ids'])))
            : [];
        unset($data['featured_media_ids']);

        $this->productMediaIds = is_array($data['product_media_ids'] ?? null)
            ? array_values(array_filter(array_map(fn($v) => (int) $v, $data['product_media_ids'])))
            : [];
        unset($data['product_media_ids']);

        // Legacy sync
        $data['featured_media_id'] = $this->featuredMediaIds[0] ?? null;

        $data['type'] = 'static_post';

        if (empty($data['author_id']) && auth()->check()) {
            $data['author_id'] = auth()->id();
        }

        $data['status'] = $data['status'] ?? 'draft';

        /** @var Slugger $slugger */
        $slugger = app(Slugger::class);

        $data['slug'] = empty($data['slug'])
            ? $slugger->uniqueGlobalSlugFromTitle((string) ($data['title'] ?? ''), ignorePostId: null)
            : $slugger->uniqueGlobalSlugFromSlug((string) $data['slug'], ignorePostId: null);

        return $data;
    }

    protected function afterCreate(): void
    {
        $this->syncMediaRole('featured', $this->featuredMediaIds);
        $this->syncMediaRole('product', $this->productMediaIds);

        Cache::forget('cms:sitemap:xml:v2');

        Notification::make()
            ->title('Static Post created')
            ->success()
            ->send();
    }

    private function syncMediaRole(string $role, array $idsIn): void
    {
        if (!$this->record) {
            return;
        }

        $seen = [];
        $ids = [];
        foreach ($idsIn as $id) {
            $id = (int) $id;
            if ($id <= 0 || isset($seen[$id])) {
                continue;
            }
            $seen[$id] = true;
            $ids[] = $id;
        }

        if ($ids === []) {
            $this->record->mediaPivot()->wherePivot('role', $role)->detach();
            return;
        }

        $sync = [];
        foreach ($ids as $i => $id) {
            $sync[$id] = ['role' => $role, 'sort_order' => $i];
        }

        // remove only that role, then attach
        $this->record->mediaPivot()->wherePivot('role', $role)->detach();
        $this->record->mediaPivot()->attach($sync);
    }
}
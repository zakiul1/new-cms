<?php

namespace Plugins\StaticPosts\Filament\Resources\StaticCategories\Tables;

use Filament\Tables;
use Filament\Tables\Table;

class StaticCategoriesTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id')->sortable(),
                Tables\Columns\TextColumn::make('name')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('parent.name')->label('Parent')->toggleable(),
                Tables\Columns\TextColumn::make('visibility')->badge()->sortable(),
                Tables\Columns\TextColumn::make('updated_at')->since()->sortable(),
                Tables\Columns\TextColumn::make('items_count')->label('Items')->sortable(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\ViewAction::make()->visible(false),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }
}
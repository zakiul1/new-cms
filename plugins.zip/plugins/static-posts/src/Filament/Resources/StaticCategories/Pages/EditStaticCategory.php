<?php

namespace Plugins\StaticPosts\Filament\Resources\StaticCategories\Pages;

use Filament\Resources\Pages\EditRecord;
use Plugins\StaticPosts\Filament\Resources\StaticCategories\StaticCategoryResource;

class EditStaticCategory extends EditRecord
{
    protected static string $resource = StaticCategoryResource::class;
}
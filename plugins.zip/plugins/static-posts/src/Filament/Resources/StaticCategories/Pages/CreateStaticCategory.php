<?php

namespace Plugins\StaticPosts\Filament\Resources\StaticCategories\Pages;

use Filament\Resources\Pages\CreateRecord;
use Plugins\StaticPosts\Filament\Resources\StaticCategories\StaticCategoryResource;

class CreateStaticCategory extends CreateRecord
{
    protected static string $resource = StaticCategoryResource::class;

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        // Force taxonomy_id = static_category
        $taxonomyId = \App\Models\Taxonomy::where('key', 'static_category')->value('id');
        $data['taxonomy_id'] = $taxonomyId;

        return $data;
    }
}
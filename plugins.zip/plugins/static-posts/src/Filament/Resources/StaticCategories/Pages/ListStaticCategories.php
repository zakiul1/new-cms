<?php

namespace Plugins\StaticPosts\Filament\Resources\StaticCategories\Pages;

use Filament\Resources\Pages\ListRecords;
use Plugins\StaticPosts\Filament\Resources\StaticCategories\StaticCategoryResource;

class ListStaticCategories extends ListRecords
{
    protected static string $resource = StaticCategoryResource::class;
}